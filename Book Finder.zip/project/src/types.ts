export interface Book {
  title: string;
  author: string;
  genre: string;
  description: string;
  coverUrl?: string;
  link?: string;
}