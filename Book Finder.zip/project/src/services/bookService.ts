import { Book } from '../types';
import { mockRecommendations } from './mockData';
import OpenAI from 'openai';

// Session storage to track previously recommended books
let previousRecommendations: string[] = [];

// This would be replaced with actual OpenAI API integration
export const generateBookRecommendations = async (query: string): Promise<Book[]> => {
  // In a production environment, you would use the OpenAI API like this:
  /*
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  const response = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are a helpful assistant that recommends books based on user preferences."
      },
      {
        role: "user",
        content: `Recommend 5 books that match the following criteria: ${query}. 
                  Format your response as a JSON array with objects containing title, author, genre, description, and optionally coverUrl and link.`
      }
    ],
    response_format: { type: "json_object" }
  });

  const recommendations = JSON.parse(response.choices[0].message.content).books;
  */

  // For demo purposes, we'll use mock data with a delay to simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      // Filter mock data based on query to simulate search
      const searchTerms = query.toLowerCase().split(' ');
      
      // Get all potential matches
      const potentialMatches = mockRecommendations.filter(book => {
        const bookText = `${book.title} ${book.author} ${book.genre} ${book.description}`.toLowerCase();
        return searchTerms.some(term => bookText.includes(term));
      });
      
      // If no matches, use a subset of mock data
      let candidateBooks = potentialMatches.length > 0 
        ? potentialMatches 
        : mockRecommendations;
      
      // Filter out previously recommended books
      const freshBooks = candidateBooks.filter(book => 
        !previousRecommendations.includes(book.title)
      );
      
      // If we have enough fresh books, use them
      // Otherwise, mix some fresh books with least recently recommended ones
      let selectedBooks: Book[] = [];
      
      if (freshBooks.length >= 5) {
        // Randomize the order of fresh books
        selectedBooks = getRandomBooks(freshBooks, 5);
      } else {
        // Use all available fresh books
        selectedBooks = [...freshBooks];
        
        // If we need more books, get some from the full list
        // that weren't recommended most recently
        const remainingNeeded = 5 - selectedBooks.length;
        
        if (remainingNeeded > 0) {
          // Sort books by how recently they were recommended
          // (books not in previousRecommendations come first)
          const sortedByRecency = [...candidateBooks].sort((a, b) => {
            const indexA = previousRecommendations.indexOf(a.title);
            const indexB = previousRecommendations.indexOf(b.title);
            
            // If a book wasn't recommended before, it gets priority
            if (indexA === -1) return -1;
            if (indexB === -1) return 1;
            
            // Otherwise, prefer books that were recommended longer ago
            return indexB - indexA;
          });
          
          // Add books until we have 5, avoiding duplicates
          for (const book of sortedByRecency) {
            if (selectedBooks.length >= 5) break;
            if (!selectedBooks.some(b => b.title === book.title)) {
              selectedBooks.push(book);
            }
          }
        }
      }
      
      // Update the list of previously recommended books
      // Keep only the most recent recommendations (up to 15 books)
      const newRecommendedTitles = selectedBooks.map(book => book.title);
      previousRecommendations = [...newRecommendedTitles, ...previousRecommendations].slice(0, 15);
      
      // Ensure we have stable results with consistent data
      resolve(selectedBooks.map(book => ({
        ...book,
        coverUrl: book.coverUrl || undefined
      })));
    }, 1500);
  });
};

// Function to get random books from a list
const getRandomBooks = (books: Book[], count: number): Book[] => {
  // Create a copy and shuffle it
  const shuffled = [...books].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, shuffled.length));
};

// Function to fetch book cover images from Open Library API
export const fetchBookCover = async (title: string, author: string): Promise<string | null> => {
  try {
    const query = encodeURIComponent(`${title} ${author}`);
    const response = await fetch(`https://openlibrary.org/search.json?q=${query}&limit=1`);
    const data = await response.json();
    
    if (data.docs && data.docs.length > 0 && data.docs[0].cover_i) {
      return `https://covers.openlibrary.org/b/id/${data.docs[0].cover_i}-M.jpg`;
    }
    return null;
  } catch (error) {
    console.error('Error fetching book cover:', error);
    return null;
  }
};