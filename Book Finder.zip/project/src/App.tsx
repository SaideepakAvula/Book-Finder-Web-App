import React, { useState } from 'react';
import { BookSearch } from './components/BookSearch';
import { BookList } from './components/BookList';
import { Book } from './types';
import { generateBookRecommendations } from './services/bookService';
import { BookOpen, Library, History } from 'lucide-react';

function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    setError(null);
    setHasSearched(true);
    
    try {
      const recommendations = await generateBookRecommendations(query);
      setBooks(recommendations);
      // Add to search history (avoid duplicates)
      if (!searchHistory.includes(query)) {
        setSearchHistory(prev => [query, ...prev].slice(0, 5));
      }
    } catch (err) {
      setError('Failed to fetch book recommendations. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleHistoryClick = (query: string) => {
    handleSearch(query);
    setShowHistory(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-100">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center">
            <BookOpen className="h-8 w-8 text-indigo-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-800">Book Finder</h1>
          </div>
          {searchHistory.length > 0 && (
            <button 
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center text-indigo-600 hover:text-indigo-800 transition-colors"
            >
              <History className="h-5 w-5 mr-1" />
              <span className="text-sm font-medium">Search History</span>
            </button>
          )}
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          {showHistory && searchHistory.length > 0 && (
            <div className="bg-white rounded-lg shadow-lg p-4 mb-6 animate-fadeIn">
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Recent Searches</h3>
              <div className="flex flex-wrap gap-2">
                {searchHistory.map((query, index) => (
                  <button
                    key={index}
                    onClick={() => handleHistoryClick(query)}
                    className="px-3 py-2 bg-indigo-100 text-indigo-700 rounded-lg text-sm hover:bg-indigo-200 transition-colors"
                  >
                    {query}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Library className="h-5 w-5 text-indigo-600 mr-2" />
              Find Your Next Great Read
            </h2>
            <p className="text-gray-600 mb-6">
              Search for books by genre, author, theme, or mood. Our AI will recommend books tailored to your preferences.
            </p>
            
            <BookSearch onSearch={handleSearch} isLoading={isLoading} />
          </div>
          
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-8 rounded">
              <p className="text-red-700">{error}</p>
            </div>
          )}
          
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
            </div>
          ) : (
            hasSearched && (
              books.length > 0 ? (
                <BookList books={books} />
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
                  <p className="text-yellow-700">No books found matching your criteria. Try a different search.</p>
                </div>
              )
            )
          )}
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>© 2025 Book Finder App. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;