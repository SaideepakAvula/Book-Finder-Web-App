import React, { useState } from 'react';
import { Book } from '../types';
import { BookOpen, User, Tag, Info } from 'lucide-react';

interface BookCardProps {
  book: Book;
}

export const BookCard: React.FC<BookCardProps> = ({ book }) => {
  const [imageError, setImageError] = useState(false);
  // Simplify the placeholder URL and encode properly
  const placeholderTitle = encodeURIComponent(book.title.substring(0, 15));
  const placeholderImage = `https://via.placeholder.com/200x300/6366F1/FFFFFF?text=${placeholderTitle}`;
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/3 h-48 md:h-auto relative bg-indigo-100">
          {book.coverUrl && !imageError ? (
            <img 
              src={book.coverUrl} 
              alt={`Cover of ${book.title}`} 
              className="w-full h-full object-cover"
              onError={() => setImageError(true)}
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-indigo-100">
              <div className="flex flex-col items-center justify-center w-full h-full p-4 text-center">
                <BookOpen className="h-12 w-12 text-indigo-600 mb-2" />
                <span className="text-indigo-700 font-medium text-sm">{book.title}</span>
              </div>
            </div>
          )}
        </div>
        
        <div className={`p-5 ${book.coverUrl ? 'md:w-2/3' : 'w-full'}`}>
          <h3 className="text-xl font-bold text-gray-800 mb-2">{book.title}</h3>
          
          <div className="flex items-center text-gray-600 mb-2">
            <User className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>{book.author}</span>
          </div>
          
          <div className="flex items-center text-gray-600 mb-3">
            <Tag className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>{book.genre}</span>
          </div>
          
          <div className="flex items-start text-gray-600 mb-4">
            <Info className="h-4 w-4 mr-2 mt-1 flex-shrink-0" />
            <p className="text-sm line-clamp-3">{book.description}</p>
          </div>
          
          {book.link && (
            <a 
              href={book.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block bg-indigo-100 text-indigo-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-200 transition-colors"
            >
              Learn More
            </a>
          )}
        </div>
      </div>
    </div>
  );
};