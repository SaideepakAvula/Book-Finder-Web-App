import React from 'react';
import { Book } from '../types';
import { BookCard } from './BookCard';
import { BookOpen } from 'lucide-react';

interface BookListProps {
  books: Book[];
}

export const BookList: React.FC<BookListProps> = ({ books }) => {
  return (
    <div className="animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          <BookOpen className="h-6 w-6 text-indigo-600 mr-2" />
          Recommended Books
        </h2>
        <span className="text-sm text-gray-500">
          {books.length} {books.length === 1 ? 'book' : 'books'} found
        </span>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {books.map((book, index) => (
          <BookCard key={`${book.title}-${index}`} book={book} />
        ))}
      </div>
    </div>
  );
};