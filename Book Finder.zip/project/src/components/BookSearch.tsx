import React, { useState, useEffect } from 'react';
import { Search, RefreshCw } from 'lucide-react';

interface BookSearchProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

export const BookSearch: React.FC<BookSearchProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');
  const [placeholder, setPlaceholder] = useState('');

  const placeholderExamples = [
    "fantasy books with strong female protagonists",
    "sci-fi novels about time travel",
    "mystery books set in small towns",
    "historical fiction during World War II",
    "books similar to Harry Potter",
    "dystopian novels with social commentary",
    "romance books with enemies to lovers",
    "adventure books with treasure hunts",
    "books with unreliable narrators",
    "magical realism novels from Latin America"
  ];

  // Rotate placeholder text every 8 seconds
  useEffect(() => {
    const getRandomPlaceholder = () => {
      const randomIndex = Math.floor(Math.random() * placeholderExamples.length);
      setPlaceholder(placeholderExamples[randomIndex]);
    };
    
    getRandomPlaceholder();
    const interval = setInterval(getRandomPlaceholder, 8000);
    
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  const suggestionCategories = [
    { label: "Fantasy", query: "fantasy books with adventure" },
    { label: "Mystery", query: "mystery thriller with plot twists" },
    { label: "Sci-Fi", query: "science fiction with space exploration" },
    { label: "Romance", query: "romance books with happy endings" },
    { label: "Historical", query: "historical fiction based on true events" },
    { label: "Dystopian", query: "dystopian novels with rebellion" },
    { label: "Young Adult", query: "young adult books with coming of age" },
    { label: "Horror", query: "horror books that are psychological" }
  ];

  return (
    <div>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Try: "${placeholder}"`}
            className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
            disabled={isLoading}
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {suggestionCategories.map((category, index) => (
            <button
              key={index}
              type="button"
              onClick={() => setQuery(category.query)}
              className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm hover:bg-indigo-200 transition-colors"
            >
              {category.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              const randomCategory = suggestionCategories[Math.floor(Math.random() * suggestionCategories.length)];
              setQuery(randomCategory.query);
            }}
            className="px-3 py-1 bg-indigo-500 text-white rounded-full text-sm hover:bg-indigo-600 transition-colors flex items-center"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Random
          </button>
        </div>
        
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="bg-indigo-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Searching...' : 'Find Books'}
        </button>
      </form>
    </div>
  );
};